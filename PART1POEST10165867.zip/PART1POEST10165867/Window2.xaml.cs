﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PART1POEST10165867
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private List<WorkRecord> workRecords = new List<WorkRecord>();


        public Window2()
        {
            InitializeComponent();
     
        }
        private void RecordHours_Click(object sender, RoutedEventArgs e)
        {
            // Update the self-study hours remaining
            UpdateSelfStudyHoursRemaining();
        }
        private void UpdateSelfStudyHoursRemaining()
        {
            // Calculate the current week's start and end date
            DateTime currentDate = DateTime.Now;
            DateTime startOfWeek = currentDate.AddDays(DayOfWeek.Monday - currentDate.DayOfWeek);
            DateTime endOfWeek = startOfWeek.AddDays(6);

            // Filter work records for the current week
            List<WorkRecord> currentWeekWorkRecords = workRecords
                .Where(record => record.Date >= startOfWeek && record.Date <= endOfWeek)
                .ToList();

            // Calculate total hours worked for each module within the current week
            Dictionary<string, double> moduleHoursWorked = new Dictionary<string, double>();

            foreach (WorkRecord record in currentWeekWorkRecords)
            {
                if (!moduleHoursWorked.ContainsKey(record.ModuleName))
                {
                    moduleHoursWorked[record.ModuleName] = 0;
                }

                moduleHoursWorked[record.ModuleName] += record.HoursWorked;
            }

            // Calculate remaining self-study hours for each module
            foreach (var moduleName in moduleHoursWorked.Keys.ToList())
            {
                double totalHoursWorked = moduleHoursWorked[moduleName];
                double remainingSelfStudyHours = 10.0 - totalHoursWorked; // Assuming 10 hours of self-study per module per week

                // Display the remaining self-study hours for each module
                Console.WriteLine($"Module: {moduleName}, Remaining Self-Study Hours: {remainingSelfStudyHours}");
            }
        }
     private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of Window2
            Window1 window1 = new Window1();
            // Show Window2
            window1.Show();
        }

     private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

