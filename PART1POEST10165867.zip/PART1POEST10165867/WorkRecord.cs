﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PART1POEST10165867
{
    internal class WorkRecord
    {
        public DateTime Date { get; set; }
        public string ModuleName { get; set; }
        public double HoursWorked { get; set; }

        public WorkRecord(DateTime date, string moduleName, double hoursWorked)
        {
            Date = date;
            ModuleName = moduleName;
            HoursWorked = hoursWorked;
        }
    }
}
