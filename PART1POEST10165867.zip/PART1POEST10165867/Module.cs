﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PART1POEST10165867
{
    internal class Module
    {
            public string ModuleCode { get; set; }
            public string ModuleName { get; set; }
            public int Credits { get; set; }
            public int ClassHoursPerWeek { get; set; }
            public int NumberOfWeeks { get; set; }
            public DateTime StartDate { get; set; }
        public Dictionary<DateTime, double> RecordedHours { get; } = new Dictionary<DateTime, double>();
        public double SelfStudyHours
            {
                get
                {
                    // Calculate self-study hours per week based on the provided formula
                    if (NumberOfWeeks - ClassHoursPerWeek != 0)
                    {
                        return Credits * 10.0 / (NumberOfWeeks - ClassHoursPerWeek);
                    }
                    return 0;
                }
            }
        }
}
