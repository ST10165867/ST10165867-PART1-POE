﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace PART1POEST10165867
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        // Create an ObservableCollection to store the modules
        private ObservableCollection<Module> modules = new ObservableCollection<Module>();
        public ListView ModuleListView => moduleListView;
        public Window1()
        {
            InitializeComponent();
           
        }

        private void SetStartDate_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected start date from the DatePicker
            DateTime selectedStartDate = startDatePicker.SelectedDate ?? DateTime.MinValue;

            if (selectedStartDate != DateTime.MinValue)
            {
                // Use the selectedStartDate for further processing
                MessageBox.Show($"Selected Start Date: {selectedStartDate.ToShortDateString()}");
            }
            else
            {
                MessageBox.Show("Please select a valid start date.");
            }
        }

        private void btnDisplayList_Click(object sender, RoutedEventArgs e)
        {
            // Collect user input
            string moduleCode = txtCode.Text;
            string moduleName = txtName.Text;
            int credits = int.Parse(txtCredits.Text);
            int classHoursPerWeek = int.Parse(txtHours.Text);
            int numberOfWeeks = int.Parse(txtNoWeeks.Text);
            DateTime startDate = startDatePicker.SelectedDate ?? DateTime.MinValue;

            // Create a new module instance
            Module module = new Module
            {
                ModuleCode = moduleCode,
                ModuleName = moduleName,
                Credits = credits,
                ClassHoursPerWeek = classHoursPerWeek,
                NumberOfWeeks = numberOfWeeks,
                StartDate = startDate
            };

            // Add the module to the ListView
            moduleListView.Items.Add(module);

            // Clear input fields
            txtCode.Clear();
            txtName.Clear();
            txtCredits.Clear();
            txtHours.Clear();
            txtNoWeeks.Clear();
            startDatePicker.SelectedDate = null;


        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            // Clear the user input by setting the Text property of the TextBox to an empty string
            txtCode.Text = string.Empty;
            txtName.Text = string.Empty;
            txtCredits.Text = string.Empty;
            txtHours.Text = string.Empty;
            txtNoWeeks.Text = string.Empty;
            startDatePicker.Text = string.Empty;
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        private void btnRemaining_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of Window2
            Window2 window2 = new Window2();
            // Show Window2
            window2.Show();
        }
    }
}
